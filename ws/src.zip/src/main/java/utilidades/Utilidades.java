package utilidades;

public class Utilidades {

	public String calcularTratamiento(int dosis, int horas, int duracion) {
		//TODO desarrollar tratamiento
		return "Aqu� ir� el tratamiento separado por comas";
	}
	
}
